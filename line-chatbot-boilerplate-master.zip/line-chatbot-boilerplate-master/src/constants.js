export const STATE_ID = {
  STATE_DEFAULT: 0,
  // If you need, you can add more states here
};

export const SET_ACTION_TYPE = 'set';
export const RESET_ACTION_TYPE = 'reset';
export const SET_KEY_VAL_ACTION_TYPE = 'setKeyValue';
